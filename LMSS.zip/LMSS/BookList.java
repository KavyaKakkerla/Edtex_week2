
import LMSS.*;
import java.util.*;

class BookList {
    private static List<Book> books = new ArrayList<>();
    

    // Add Book
    public static void addBook() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter whether it is a fiction or non-fiction book: 1 for fiction 2 for non-fiction");
        int n = sc.nextInt();
        sc.nextLine();  // Consume newline
        if (n == 1) {
            System.out.print("Enter Book Title: ");
            String title = sc.nextLine();
            System.out.print("Enter Author: ");
            String author = sc.nextLine();
            System.out.print("Enter ISBN: ");
            int isbn = sc.nextInt();
            System.out.print("Enter Quantity: ");
            int quantity = sc.nextInt();
            books.add(new FictionBook(title, author, isbn, quantity, "Fiction"));
            System.out.println("Fiction Book added successfully.");
        } else if (n == 2) {
            System.out.print("Enter Book Title: ");
            String title = sc.nextLine();
            System.out.print("Enter Author: ");
            String author = sc.nextLine();
            System.out.print("Enter ISBN: ");
            int isbn = sc.nextInt();
            System.out.print("Enter Quantity: ");
            int quantity = sc.nextInt();
            books.add(new NonFictionBook(title, author, isbn, quantity, "Non-Fiction"));
            System.out.println("Non-Fiction Book added successfully.");
        } else {
            System.out.println("Invalid input.");
        }
    }

    // Remove Book
    public static void removeBook() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter ISBN of the book to remove: ");
        int isbn = sc.nextInt();
        boolean removed = false;

        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getIsbn() == isbn) {
                books.remove(i);
                removed = true;
                System.out.println("Book removed successfully.");
                break;
            }
        }

        if (!removed) {
            throw new Exception("Book not found.");
        }
    }

    // Display Books
    public static void displayBooks() {
        System.out.println("\nAvailable Books:");
        if (books.isEmpty()) {
            System.out.println("No books available.");
        } else {
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }
}
