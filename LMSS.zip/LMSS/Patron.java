package LMSS;
import LMSS.Borrowable;
import java.util.*;

public class Patron implements Borrowable {
    private String name;
    private int id;
    private List<Book> borrowedBooks = new ArrayList<>();

    public Patron(String name, int id) {
        this.name = name;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Book> getBorrowedBooks() {
        return borrowedBooks;
    }
    @Override
    public void borrowBook(Book book) throws Exception {
        if (book.getQuantity() > 0) {
            borrowedBooks.add(book);
            book.setQuantity(book.getQuantity() - 1);
            System.out.println(name + " borrowed " + book.getTitle());
        } else {
            throw new Exception("Book not available.");
        }
    }
    @Override
    public void returnBook(Book book) throws Exception {
        if (borrowedBooks.contains(book)) {
            borrowedBooks.remove(book);
            book.setQuantity(book.getQuantity() + 1);
            System.out.println(name + " returned " + book.getTitle());
        } else {
            throw new Exception("Book not borrowed by " + name);
        }
    }

    @Override
    public String toString() {
        return "Patron ID: " + id + ", Name: " + name + ", Borrowed Books: " + borrowedBooks.size();
    }

   
}
