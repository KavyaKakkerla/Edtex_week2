package LMSS;
public interface Borrowable {

    public void borrowBook(Book book) throws Exception;
    public void returnBook(Book book) throws Exception;

}
