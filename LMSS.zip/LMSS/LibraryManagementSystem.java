package LMSS;
import LMSS.*;
import java.util.*;


class BookList {
    private static List<Book> books = new ArrayList<>();

    public static void addBook() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter whether it is a fiction or non-fiction book: 1 for fiction 2 for non-fiction");
        int n = sc.nextInt();
        sc.nextLine(); 
        if (n == 1) {
            System.out.print("Enter Book Title: ");
            String title = sc.nextLine();
            System.out.print("Enter Author: ");
            String author = sc.nextLine();
            System.out.print("Enter ISBN: ");
            int isbn = sc.nextInt();
            System.out.print("Enter Quantity: ");
            int quantity = sc.nextInt();
            books.add(new FictionBook(title, author, isbn, quantity, "Fiction"));
            System.out.println("Fiction Book added successfully.");
        } else if (n == 2) {
            System.out.print("Enter Book Title: ");
            String title = sc.nextLine();
            System.out.print("Enter Author: ");
            String author = sc.nextLine();
            System.out.print("Enter ISBN: ");
            int isbn = sc.nextInt();
            System.out.print("Enter Quantity: ");
            int quantity = sc.nextInt();
            books.add(new NonFictionBook(title, author, isbn, quantity, "Non-Fiction"));
            System.out.println("Non-Fiction Book added successfully.");
        } else {
            System.out.println("Invalid input.");
        }
    }

    public static void removeBook() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter ISBN of the book to remove: ");
        int isbn = sc.nextInt();
        boolean removed = false;

        for (int i = 0; i < books.size(); i++) {
            if (books.get(i).getIsbn() == isbn) {
                books.remove(i);
                removed = true;
                System.out.println("Book removed successfully.");
                break;
            }
        }

        if (!removed) {
            throw new Exception("Book not found.");
        }
    }

    public static void displayBooks() {
        System.out.println("\nAvailable Books:");
        if (books.isEmpty()) {
            System.out.println("No books available.");
        } else {
            for (Book book : books) {
                System.out.println(book);
            }
        }
    }

    public static Book findBookByIsbn(int isbn) throws Exception {
        for (Book book : books) {
            if (book.getIsbn() == isbn) {
                return book;
            }
        }
        throw new Exception("Book not found.");
    }
}


class PatronList {
    private static List<Patron> patrons = new ArrayList<>();

    public static void addPatron() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Patron Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Patron ID: ");
        int id = sc.nextInt();
        patrons.add(new Patron(name, id));
        System.out.println("Patron added successfully.");
    }

    public static void removePatron() throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Patron ID to remove: ");
        int id = sc.nextInt();
        boolean removed = false;

        for (int i = 0; i < patrons.size(); i++) {
            if (patrons.get(i).getId() == id) {
                patrons.remove(i);
                removed = true;
                System.out.println("Patron removed successfully.");
                break;
            }
        }

        if (!removed) {
            throw new Exception("Patron not found.");
        }
    }

    public static void displayPatrons() {
        System.out.println("\nRegistered Patrons:");
        if (patrons.isEmpty()) {
            System.out.println("No patrons registered.");
        } else {
            for (Patron patron : patrons) {
                System.out.println(patron);
            }
        }
    }

    public static Patron findPatronById(int id) throws Exception {
        for (Patron patron : patrons) {
            if (patron.getId() == id) {
                return patron;
            }
        }
        throw new Exception("Patron not found.");
    }
}

// Library Management System
public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\nLibrary Management System:");
            System.out.println("1. Add Book");
            System.out.println("2. Remove Book");
            System.out.println("3. Display Books");
            System.out.println("4. Add Patron");
            System.out.println("5. Remove Patron");
            System.out.println("6. Display Patrons");
            System.out.println("7. Borrow Book");
            System.out.println("8. Return Book");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            try {
                switch (choice) {
                    case 1:
                        BookList.addBook();
                        break;
                    case 2:
                        BookList.removeBook();
                        break;
                    case 3:
                        BookList.displayBooks();
                        break;
                    case 4:
                        PatronList.addPatron();
                        break;
                    case 5:
                        PatronList.removePatron();
                        break;
                    case 6:
                        PatronList.displayPatrons();
                        break;
                    case 7: {
                        System.out.print("Enter Patron ID: ");
                        int id = sc.nextInt();
                        Patron patron = PatronList.findPatronById(id);

                        BookList.displayBooks();
                        System.out.print("Enter ISBN of the book to borrow: ");
                        int isbn = sc.nextInt();
                        Book book = BookList.findBookByIsbn(isbn);

                        patron.borrowBook(book);
                        break;
                    }
                    case 8: {
                        System.out.print("Enter Patron ID: ");
                        int id = sc.nextInt();
                        Patron patron = PatronList.findPatronById(id);

                        System.out.print("Enter ISBN of the book to return: ");
                        int isbn = sc.nextInt();
                        Book book = BookList.findBookByIsbn(isbn);

                        patron.returnBook(book);
                        break;
                    }
                    case 9:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
